# LaTeX2HTML 2K.1beta (1.47)
# Associate images original text with physical files.


$key = q/includegraphics[width=0.8textwidth]{figuresslashnetwork-layout-adsl-1card};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="443" HEIGHT="354" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\includegraphics[width=0.8\textwidth]{figures/network-layout-adsl-1card}">|; 

$key = q/includegraphics[width=0.8textwidth]{figuresslashnetwork-layout};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="442" HEIGHT="307" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[width=0.8\textwidth]{figures/network-layout}">|; 

$key = q/includegraphics[width=0.8textwidth]{figuresslashmodem};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="444" HEIGHT="313" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[width=0.8\textwidth]{figures/modem}">|; 

$key = q/includegraphics[width=0.8textwidth]{figuresslashnetwork-layout-adsl-2cards};FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="444" HEIGHT="325" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\includegraphics[width=0.8\textwidth]{figures/network-layout-adsl-2cards}">|; 

1;

