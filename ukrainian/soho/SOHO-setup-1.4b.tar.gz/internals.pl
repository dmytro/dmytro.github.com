# LaTeX2HTML 2K.1beta (1.47)
# Associate internals original text with physical files.


$key = q/cite_ipforward/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fetchmail/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ipchains/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_diald/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/modem-connection/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/one-netcard/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/network-layout/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ipmasq/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/private-ip/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_natd/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/two-netcards/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pppoe/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_connect/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_privateip/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/security/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_deb/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_macosxorg-natd/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dns/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pppd/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nat/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

1;

